//created by Militant Saungweme

var auth = firebase.auth();
var storageRef = firebase.storage().ref();
var  currentTime = new Date();



function clearTextFields() {
    document.getElementById('title').value='';
    document.getElementById('author').value='';
    document.getElementById('body').value='';
}
function getTextFieldValues() {

    title = document.getElementById('title').value;
    author = document.getElementById('author').value;
    body = document.getElementById('body').value;
    image = document.getElementById('image').value;

}
function handleFileSelect(evt) {
    evt.stopPropagation();
    evt.preventDefault();
    var file = evt.target.files[0];

    var metadata = {
        'contentType': file.type
    };

    // Push to child path.
    // [START oncomplete]


    //declare uploadTask variable

    var uploadTask = storageRef.child('images/' + file.name).put(file, metadata);
    // Listen for state changes, errors, and completion of the upload.
    uploadTask.on(firebase.storage.TaskEvent.STATE_CHANGED, // or 'state_changed'
        function(snapshot) {
            // Get task progress, including the number of bytes uploaded and the total number of bytes to be uploaded
            var progress = (snapshot.bytesTransferred / snapshot.totalBytes) * 100;
            //show progress bar

            var progressBar ='<div class="progress">'+
                 '<div class="progress-bar progress-bar-info progress-bar-striped" role="progressbar" value="'+progress+'" aria-valuemin="0" aria-valuemax="100" style="width:'+progress+'%">'+
                '</div>'+
                '</div>';

            document.getElementById('progress').innerHTML = progressBar;



            //enable the submit button when image finishes to upload
            if (progress == 100){
                document.getElementById('submit').disabled = false;
                document.getElementById('imagepath').style.visibility = "visible";
                document.getElementById('progress').style.visibility = "hidden";
            }
            document.getElementById('image').value=uploadTask.snapshot.downloadURL;
            console.log('Upload is ' + progress + '% done');

            console.log(uploadTask.snapshot);
            switch (snapshot.state) {
                case firebase.storage.TaskState.PAUSED: // or 'paused'
                    console.log('Upload is paused');
                    break;
                case firebase.storage.TaskState.RUNNING: // or 'running'
                    console.log('Upload is running');
                    break;
            }
        }, function(error) {
            switch (error.code) {
                case 'storage/unauthorized':
                    // User doesn't have permission to access the object
                    break;

                case 'storage/canceled':
                    // User canceled the upload
                    break;

                    case 'storage/unknown':
                    // Unknown error occurred, inspect error.serverResponse
                    break;
            }
        }, function() {
            // Upload completed successfully, now we can get the download URL
            var downloadURL = uploadTask.snapshot.downloadURL;
            console.log(downloadURL);
        });

}
function createArticle (title, author ,body,image ) {
    title = document.getElementById('title').value;
    author = document.getElementById('author').value;
    body = document.getElementById('body').value;
    image = document.getElementById('image').value;
    var  currentTime = new Date();
    console.log(currentTime.getTime());


    firebase.database().ref('article/').push(
        {
            //in the meantime I just want to store these three fields for the agent
            "title": title,
            "author": author,
            "body": body,
            "imagePath": image,
            "dateCreated": image
        }
    );


      //clear text feilds after you send data to firebase----

      clearTextFields();

}

firebase.database().ref('article/').limitToLast(10).on('child_added', function(snapshot) {
    console.log(snapshot);

    var article= snapshot.val();


    console.log(article);
    console.log(snapshot.key);
    articleTitle = article.title;
    articleAuthor = article.author;
    articleBody = article.body;
    key = snapshot.key;

    localStorage.setItem("title",articleTitle);
    localStorage.setItem("author",articleAuthor);
    localStorage.setItem("body", articleBody);
    localStorage.setItem("key", key);

    console.log(localStorage.getItem("body"));

    function edit (){
        // document.getElementById('title').value = localStorage.getItem("title");
        // document.getElementById('author').value = localStorage.getItem("author");
        // document.getElementById('body').value = localStorage.getItem("body");

    }edit();


    this.renderArticle = function(title, image){

        var myKey = snapshot.key;
        return '<li id="'+myKey+'" class="list-group-item"><div class="row"><div class="col-sm-8">'+title+'</div><div class="col-sm-2">' +
               '<button id="'+myKey+'" onclick="updateData(this.id)" type="button" class="btn btn-sm btn-primary">Edit</button>' +
               '</div>' +
               '<div class="col-sm-2"><button onclick="setAttributeValue(this.id)" id="'+myKey+'" type="button" class="btn btn-sm btn-danger" data-toggle="modal" data-target="#myModal">Delete</button></div>'+
               '</div></li>';





    };//renderUserData

    //some jquery to remove the loader from html when articles populate
    $("#loader").remove();



    $("#articles").append(this.renderArticle(article.title));

//beauty

});



//UPDATE DATA

function updateData(id){

    console.log(id);
    document.getElementById('articles').style.visibility = "hidden";
    document.getElementById('submit').style.visibility = "hidden";
    document.getElementById('update').style.visibility = "visible";
    document.getElementById('create').innerHTML= "UPDATE";
    document.getElementById('update').setAttribute("id", id);

    firebase.database().ref("article/"+id+"/").on("value", function(snapshot) {
        console.log(snapshot);
        var art= snapshot.val();
        console.log(art);

        document.getElementById('title').value = art.title;
        document.getElementById('body').value = art.body;
        document.getElementById('author').value = art.author;


    });




}//updateData


function setAttributeValue(id) {
    document.getElementById('buttondelete').setAttribute("id", id);
}

//this is where the real updating of data happens
function postData(id) {
    getTextFieldValues();

        firebase.database().ref("article/"+id+"/").update(
            {
                //in the meantime I just want to store these three fields for the agent
                "title": title,
                "author": author,
                "body": body,
                "imagePath": image,
                "dateCreated": image
            }
        ).then(function reload () {
            window.location='index.html';
        });


}
//this function deletes child node
//and removes the deleted child from the page
function deleteData(id) {

    firebase.database().ref("article/"+id+"/").remove();
    $('#'+id).remove();

}

/**
 * Created by HP ELITEBOOK on 3/2/2017.
 */
function handleVideoDownload(evt) {
    evt.stopPropagation();
    evt.preventDefault();
    var file = evt.target.files[0];

    var metadata = {
        'contentType': file.type
    };

    // Push to child path.
    // [START oncomplete]


    //declare uploadTask variable

    var uploadTask = storageRef.child('videos/' + file.name).put(file, metadata);
    // Listen for state changes, errors, and completion of the upload.
    uploadTask.on(firebase.storage.TaskEvent.STATE_CHANGED, // or 'state_changed'
        function(snapshot) {
            // Get task progress, including the number of bytes uploaded and the total number of bytes to be uploaded
            var progress = (snapshot.bytesTransferred / snapshot.totalBytes) * 100;
            //show progress bar

            var progressBar ='<div class="progress">'+
                '<div class="progress-bar progress-bar-info progress-bar-striped" role="progressbar" value="'+progress+'" aria-valuemin="0" aria-valuemax="100" style="width:'+progress+'%">'+
                '</div>'+
                '</div>';

            document.getElementById('progress').innerHTML = progressBar;



            //enable the submit button when image finishes to upload
            if (progress == 100){
                document.getElementById('submit').disabled = false;
                document.getElementById('imagepath').style.visibility = "visible";
                document.getElementById('progress').style.visibility = "hidden";
            }
            document.getElementById('image').value=uploadTask.snapshot.downloadURL;
            console.log('Upload is ' + progress + '% done');

            console.log(uploadTask.snapshot);
            switch (snapshot.state) {
                case firebase.storage.TaskState.PAUSED: // or 'paused'
                    console.log('Upload is paused');
                    break;
                case firebase.storage.TaskState.RUNNING: // or 'running'
                    console.log('Upload is running');
                    break;
            }
        }, function(error) {
            switch (error.code) {
                case 'storage/unauthorized':
                    // User doesn't have permission to access the object
                    break;

                case 'storage/canceled':
                    // User canceled the upload
                    break;

                case 'storage/unknown':
                    // Unknown error occurred, inspect error.serverResponse
                    break;
            }
        }, function() {
            // Upload completed successfully, now we can get the download URL
            var downloadURL = uploadTask.snapshot.downloadURL;
            console.log(downloadURL);
        });

}



