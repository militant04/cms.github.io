/**
 * Created by HP ELITEBOOK on 2/28/2017.
 */

var auth = firebase.auth();
var storageRef = firebase.storage().ref();

function uploadArticle() {


    var file = document.getElementById('file').target.files[0];

    var metadata = {
        'contentType': file.type
    };
    function writeUserData (name, surname ,address,position ) {
        name = document.getElementById('name').value;
        surname = document.getElementById('surname').value;
        address = document.getElementById('email').value;
        position = document.getElementById('position').value;


        firebase.database().ref('users/').push(
            {
                //in the meantime I just want to store these three fields for the agent
                "fname": name,
                "surname": surname,
                "address": address,
                "position": position
            }
        );
//okay twas really no problem posting data to the freaking DB
// now I gotta get back my data and print it on the dashboard----
    }



}
