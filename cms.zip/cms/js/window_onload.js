/**
 * Created by HP ELITEBOOK on 3/1/2017.
 */

// Register three observers:
// 1. 'state_changed' observer, called any time the state changes
// 2. Error observer, called on failure
// 3. Completion observer, called on successful completion

window.onload = function() {
    document.getElementById('file').addEventListener('change', handleFileSelect, false);
    document.getElementById('video').addEventListener('change', handleVideoDownload, false);
    document.getElementById('file').disabled = true;
    document.getElementById('submit').disabled = true;
   // document.getElementById('imagepath').style.visibility = "hidden";


    auth.onAuthStateChanged(function(user) {
        if (user) {
            console.log('Anonymous user signed-in.', user);
            document.getElementById('file').disabled = false;
        } else {
            console.log('There was no anonymous session. Creating a new anonymous user.');
            // Sign the user in anonymously since accessing Storage requires the user to be authorized.
            auth.signInAnonymously();
        }
    });
};
